#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "kernel.cu"

int main (int argc, char *argv[]){

    float *A_h, *B_h, *C_h;
    float *A_d, *B_d, *C_d;    
    unsigned VecSize;
    int blocksPerGrid, threadsPerBlock;

    if (argc == 4) {
        VecSize = atoi(argv[1]);
        blocksPerGrid = atoi(argv[2]);
        threadsPerBlock = atoi(argv[3]);
    } else {
        printf("Usage: ./vecadd <VecSize> <numBlocks> <threadsPerBlock>\n");
        exit(0);
    }

    A_h = (float*) malloc( sizeof(float) * VecSize );
	B_h = (float*) malloc( sizeof(float) * VecSize );
	C_h = (float*) malloc( sizeof(float) * VecSize );
	
    for (unsigned int i=0; i < VecSize; i++) {
		A_h[i] = i;
		B_h[i] = i;
	}    

    cudaDeviceSynchronize();
    
    cudaMalloc((void**)&A_d, sizeof(float) * VecSize);
    cudaMalloc((void**)&B_d, sizeof(float) * VecSize);
    cudaMalloc((void**)&C_d, sizeof(float) * VecSize);

    cudaMemcpy(A_d, A_h, sizeof(float) * VecSize, cudaMemcpyHostToDevice);
    cudaMemcpy(B_d, B_h, sizeof(float) * VecSize, cudaMemcpyHostToDevice);

    cudaDeviceSynchronize();

    clock_t start = clock();
    VecAdd<<<blocksPerGrid, threadsPerBlock>>>(A_d, B_d, C_d, VecSize);
    cudaDeviceSynchronize();
    clock_t end = clock();

    double elapsed_ms = 1000.0 * (double)(end - start) / CLOCKS_PER_SEC;
    printf("%u,%d,%d,%.4f\n", VecSize, blocksPerGrid, threadsPerBlock, elapsed_ms);

    cudaMemcpy(C_h, C_d, sizeof(float) * VecSize, cudaMemcpyDeviceToHost);

    free(A_h);
    free(B_h);
    free(C_h);
    cudaFree(A_d);
    cudaFree(B_d);
    cudaFree(C_d);

    return 0;
}