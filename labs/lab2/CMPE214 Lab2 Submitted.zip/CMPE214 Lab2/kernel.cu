#include <stdio.h>
 
__global__ void VecAdd(const float *A, const float *B, float* C, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        C[i] = A[i] + B[i];
    }
}